import json

class ListaCompras:
    def __init__(self):
        self.arquivo = "lista.json"
        self.lista = self.carregar_arquivo()

    def carregar_arquivo(self):
       #le o arquivo .JSON e carrega os itens para a lista ao iniciar
        try:
            with open(self.arquivo, "r", encoding="utf-8") as f:
                #o .strip() remove o 'pulo de linha' (\n) ao ler
                return json.load(f)
        except (FileNotFoundError,json.JSONDecodeError):
            return [] #se o arquivo não existir ainda, retorna lista vazia

    def salvar_no_arquivo(self):
        #sobrescreve o arquivo com todos os itens atuais da lista"""
        with open(self.arquivo, "w", encoding="utf-8") as f:
           json.dump(self.lista, f, ensure_ascii=False, indent=4)
    def excluir_item(self):
        if not self.lista:
            print("A lista está vazia, nao tem nada para excluir.")
            return

        print("\nQual item deseja remover?")
        for i, item in enumerate(self.lista, 1):
            print(f"{i}. {item['item']}")
        # mostra os itens que tem na lista numerados
        try:
            indice = int(input("\nDigite o número do item: ")) - 1
            if 0 <= indice < len(self.lista):
                removido = self.lista.pop(indice) #remove pelo índice
                self.salvar_no_arquivo()          #atualiza o JSON
                print(f"item '{removido['item']}' removido com sucesso!")
            else:
                print("Numero inválido!")
        except ValueError:
            print("ERRO: digite apenas números.")


    def iniciar(self):
        while True:
            print(f'\n *LISTA DE COMPRAS* ')
            opcao = input("ESCOLHA UMA DAS SEGUINTE OPÇOES: (1-adicionar / 2-visualizar / 3-descrição / 4-excluir / 5-sair): ").lower()

            if opcao == "adicionar" or opcao == "1":
                item = input("Digite o item: ").strip()
                if item == "":
                    print("\nERRO: nao tem nada!")
                    continue
                self.lista.append({"item": item})
                self.salvar_no_arquivo() #salva toda vez que adiciona
                print("Item adicionado e salvo!")

            elif opcao == "visualizar" or opcao == "2":
                print("\nSUA LISTA:")
                if not self.lista:
                    print("A lista está vazia.")
                else:
                    for i in self.lista:
                        print(f"- {i['item']}")

            elif opcao == "descrição" or opcao == "3":
                print("atividade somativa 2,lista para compras feita por Davi Kenji, com JSON")

            elif opcao == "excluir_item" or  opcao == "4":
                self.excluir_item()

            elif opcao == "sair" or opcao == "5":
                self.salvar_no_arquivo()
                print("tudo salvo com sucesso!, saindo...")
                break
            else:
                print("COMANDO INVALIDO.")

#execução
app = ListaCompras()
app.iniciar()
